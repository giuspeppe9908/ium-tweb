package com.example.anotherservletproject.servlets;

import com.google.gson.Gson;
import com.example.anotherservletproject.dao.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.http.HttpResponse;
import java.util.ArrayList;
import java.util.List;

@WebServlet(name = "bookingServlet", value = "/booking-servlet")
public class BookingServlet extends HttpServlet {
    private String message;
    Gson json = new Gson();
    public void init() {
        message = "YOUR CURRENT BOOKING LIST";
        DAO.registerDriver();
    }

    /*public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("text/html");
        HttpSession session = request.getSession();
        String user = (String) session.getAttribute("user");
        String id_ute = DAO.UserID(user);
        Prenotazioni p = DAO.showPersonalBooking(id_ute);
        PrintWriter out = response.getWriter();
        out.println("<html><body>");
        out.println("<h1>" + message + "</h1>");
        for(Prenotazione u : p){
            out.println("<p>"+ u + "</p>");
        }
        out.println("<form action=\"logout-servlet\" method=\"post\">");
        out.println("<p><input type=\"submit\" value=\"Log Out\" id=\"btnlogout\" name=\"btnlogout\"/></p>");
        out.println("</form>");
        out.println("</body></html>");
    }*/

    /*@Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json");
        String id_c = req.getParameter("id_c");
        String day = req.getParameter("day");
        String hour = req.getParameter("hour");
        PrintWriter out = resp.getWriter();
        HttpSession session = req.getSession();
        String user = (String) session.getAttribute("user");
        String stato = req.getParameter("stato");
        String id_ute = DAO.UserID(user);
        Prenotazione p = new Prenotazione(id_ute, id_c, hour, day, stato);
        Prenotazioni lp = DAO.retrieveList();
        boolean flag = false;
        for(Prenotazione pr : lp) {
            System.out.println("[ "+pr+" ]");
            //Controllo se ho la stessa prenotazione nello stesso giorno e nella stessa ora
            if(p.getO_p().equals(pr.getO_p()) && p.getGiorno().equals(pr.getGiorno())){
                flag = true;
                p.setStato("disabled");
                System.out.println("Stato prenotazione : "+p.getStato());
                DAO.UpdateStatoPrenotazione(p);
                break;
            }
        }
        if(!flag){
            DAO.InsertPrenotazioni(p);
            lp.inserisci(p);
        }
        String jsonStr = json.toJson(lp);
        System.out.println("Gson wrote : "+jsonStr);
        out.flush();
    }*/

    public void destroy() {
    }
}