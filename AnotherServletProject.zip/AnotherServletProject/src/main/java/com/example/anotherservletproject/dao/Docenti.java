package com.example.anotherservletproject.dao;

public class Docenti {

    int id;
    String nome,cognome, corso;
    public Docenti(){

    }

    public Docenti(int id, String nome, String cognome, String corso) {
        this.id = id;
        this.nome = nome;
        this.cognome = cognome;
        this.corso = corso;
    }

    public Docenti(String nome, String cognome){
        this.nome = nome;
        this.cognome = cognome;
    }
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCognome() {
        return cognome;
    }

    public void setCognome(String cognome) {
        this.cognome = cognome;
    }

    public String getCorso() {
        return corso;
    }

    public void setCorso(String corso) {
        this.corso = corso;
    }

    @Override
    public String toString() {
        return id+", "+nome + ", " + cognome + ", " + corso;
    }
}
