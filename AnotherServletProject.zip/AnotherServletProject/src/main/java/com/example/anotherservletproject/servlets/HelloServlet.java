package com.example.anotherservletproject.servlets;

import com.example.anotherservletproject.dao.DAO;
import com.example.anotherservletproject.dao.Insegnamento;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

@WebServlet(name = "helloServlet", value = "/hello-servlet")
public class HelloServlet extends HttpServlet {

    private String message;

    public void init() {
        message = "LIST OF TEACHINGS-TEACHERS ASSOCIATION!";
        DAO.registerDriver();
    }

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("text/html");
        //ArrayList<Utenti> p = DAO.queryDButenti();
        //System.out.println("...Insert teaching...");
        //DAO.insertTeaching();
        ArrayList<Insegnamento> ins = DAO.queryDBIns();
        // Hello
        PrintWriter out = response.getWriter();
        out.println("<html><body>");
        out.println("<h1>" + message + "</h1>");
            for(Insegnamento i : ins){
                out.println("<p>"+ i + "</p>");
            }
        out.println("</body></html>");
    }

    public void destroy() {
    }
}