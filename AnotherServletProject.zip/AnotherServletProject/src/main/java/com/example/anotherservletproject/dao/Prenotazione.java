package com.example.anotherservletproject.dao;

public class Prenotazione {
    String id_corso, id_utente, giorno, o_p, stato;

    public Prenotazione(){

    }
    public Prenotazione(String id_utente,String id_corso, String o_p, String giorno, String stato){
        this.id_corso = id_corso;
        this.id_utente = id_utente;
        this.o_p = o_p;
        this.giorno = giorno;
        this.stato = stato;
    }

    public void setStato(String stato){
        this.stato = stato;
    }

    public String getStato(){
        return stato;
    }

    public String getId_corso() {
        return id_corso;
    }

    public void setId_corso(String id_corso) {
        this.id_corso = id_corso;
    }

    public String getId_utente() {
        return id_utente;
    }

    public void setId_utente(String id_utente) {
        this.id_utente = id_utente;
    }

    public String getGiorno() {
        return giorno;
    }

    public void setGiorno(String giorno) {
        this.giorno = giorno;
    }

    public String getO_p() {
        return o_p;
    }

    public void setO_p(String o_p) {
        this.o_p = o_p;
    }

    /*@Override
    public String toString() {
        return "Prenotazioni{" +
                "id_corso=" + getId_corso() +
                ", Orario Prenotazione = "+getO_p()+", GiornoP = "+getGiorno()+'}';
    }*/
}
