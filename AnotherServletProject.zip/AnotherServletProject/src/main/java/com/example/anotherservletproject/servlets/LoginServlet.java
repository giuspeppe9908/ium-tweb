package com.example.anotherservletproject.servlets;
import com.example.anotherservletproject.dao.DAO;

import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

@WebServlet(name = "loginServlet", urlPatterns = {"/loginServlet"})
public class LoginServlet extends HttpServlet {
    public void init() {
        DAO.registerDriver();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        System.out.println("Action is : "+action);
        if(action != null) {
            switch(action){
                case "Request role":
                    ServletGen.processRequest(request, response);
                    break;
                case "Request Mie Prenotazioni":
                    ServletGen.OwnBooking(request, response);
                    break;
                case "Request Manage Teachers":
                    ServletGen.InsertTeacher(request, response);
                    break;
                case "Request Inserisci Corso":
                    ServletGen.InsertCorso(request, response);
                    break;
                case "Request Delete Corso":
                    ServletGen.DeleteCorso(request, response);
                    break;
                case "Request Insegnamenti":
                    ServletGen.InsertTeaching(request, response);
                    break;
                case "Request Delete Insegnamento":
                    ServletGen.DeleteTeaching(request, response);
                    break;
                default: break;
            }
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        System.out.println("Action is : "+action);
        if(action != null) {
            switch(action){
                case "Request role":
                     ServletGen.processRequest(request, response);
                     break;
                case "Request Mie Prenotazioni":
                    ServletGen.OwnBooking(request, response);
                    break;
                case "Request Inserisci Corso":
                    ServletGen.InsertCorso(request, response);
                    break;
                case "Request Delete Corso":
                    ServletGen.DeleteCorso(request, response);
                    break;
                default: break;
            }
        }
    }
}
