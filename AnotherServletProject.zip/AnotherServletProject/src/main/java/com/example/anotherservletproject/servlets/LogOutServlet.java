package com.example.anotherservletproject.servlets;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet(name = "LogOutServlet", value = "/logout-servlet")
public class LogOutServlet extends HttpServlet{

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("text/html");
        Cookie[] cookie = req.getCookies();
        if(cookie != null){
            for(Cookie c : cookie){
                if(c.getName().equals("JSESSIONID")){
                    System.out.println(c.getValue());
                    break;
                }
            }
        }
        //Invalido la sessione se esiste
        HttpSession session = req.getSession(false);
        System.out.println("User = "+session.getAttribute("user"));
        if(session!=null){
            session.invalidate();
            System.out.println("Session closed!");
        }
        resp.sendRedirect("index.html");
    }


}
