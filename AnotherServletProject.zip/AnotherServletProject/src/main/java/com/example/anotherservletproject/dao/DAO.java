package com.example.anotherservletproject.dao;
import java.sql.*;
import java.util.ArrayList;
import java.util.Scanner;

public class DAO {

    private static final String url1 = "jdbc:mysql://localhost:3306/test";
    private static final String user = "root";
    private static final String password = "";
    private static Connection conn1 = null;
    public static void registerDriver() {
        try {
            //Class.forName("com.mysql.jdbc.Driver");
            DriverManager.registerDriver(new com.mysql.jdbc.Driver());
            System.out.println("Driver correttamente registrato.");
        } catch (SQLException e) {
            System.out.println("Errore: " + e.getMessage());
        }
    }

    //Query per Array Utenti/Docenti
    public static ArrayList<Docenti> queryDBDoc() {
        ArrayList<Docenti> out2 = new ArrayList<>();
        try {
            conn1 = DriverManager.getConnection(url1, user, password);
            if (conn1 != null) {
                System.out.println("Connected to the database test");
            }
            Statement st = conn1.createStatement();
            /* Query su docenti */
            ResultSet rd = st.executeQuery("SELECT * FROM docenti");
            while (rd.next()) {
                Docenti d = new Docenti(Integer.parseInt(rd.getString("ID_D")), rd.getString("NOMED"), rd.getString("COGNOMED"), rd.getString("ID_CORSO"));
                out2.add(d);
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return out2;
    }

    //Query per Array Utenti/Docenti
    public static ArrayList<Insegnamento> queryDBIns() {
        ArrayList<Insegnamento> out2 = new ArrayList<>();
        try {
            conn1 = DriverManager.getConnection(url1, user, password);
            if (conn1 != null) {
                System.out.println("Connected to the database test");
            }
            Statement st = conn1.createStatement();
            /* Query su docenti */
            ResultSet rd = st.executeQuery("SELECT insegnamento.id_corso, insegnamento.id_docente, docenti.nome, docenti.cognome FROM (insegnamento JOIN docenti ON insegnamento.id_docente = docenti.id_docente)");
            while (rd.next()) {
                Insegnamento i = new Insegnamento(Integer.parseInt(rd.getString("ID_DOCENTE")),Integer.parseInt(rd.getString("ID_CORSO")), rd.getString("NOME"), rd.getString("COGNOME"));
                out2.add(i);
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return out2;
    }

    public static ArrayList<Corsi> showCorsi() {
        ArrayList<Corsi> out2 = new ArrayList<>();
        try {
            conn1 = DriverManager.getConnection(url1, user, password);
            if (conn1 != null) {
                System.out.println("Connected to the database test");
            }
            Statement st = conn1.createStatement();
            /* Query su docenti */
            ResultSet rd = st.executeQuery("SELECT * FROM corsi");
            while (rd.next()) {
                Corsi c = new Corsi(rd.getString("TITOLI"));
                out2.add(c);
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return out2;
    }

    public static String UserID(String user2) {
        String userID = "";
        try{
                Connection conn = DriverManager.getConnection(url1, user, password);
                if (conn != null) {
                    System.out.println("Connected to the database test");
                }
                Statement st = conn.createStatement();
                ResultSet rs = st.executeQuery("SELECT ID_U FROM utenti WHERE Account='"+user2+"'");
                if(rs.next()){
                    userID = rs.getString(1);
                }
                userID = rs.getString(1);
            }catch (SQLException e) {
                System.out.println(e.getMessage());
            }
            return userID;
    }

    public static String UserRole(String user2) {
        String userRole = "";
        try{
            Connection conn = DriverManager.getConnection(url1, user, password);
            if (conn != null) {
                System.out.println("Connected to the database test");
            }
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery("SELECT Ruolo FROM utenti WHERE Account='"+user2+"'");
            if(rs.next()){
                userRole = rs.getString(1);
            }
            userRole = rs.getString(1);
        }catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return userRole;
    }

    public static String UserPassword(String user2) {
        String userP = "";
        try{
            Connection conn = DriverManager.getConnection(url1, user, password);
            if (conn != null) {
                System.out.println("Connected to the database test");
            }
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery("SELECT Password FROM utenti WHERE Account='"+user2+"'");
            if(rs.next()){
                userP = rs.getString(1);
            }
            userP = rs.getString(1);
        }catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return userP;
    }

    public static void UpdateStatoPrenotazione(Prenotazione p){
        try {
            conn1 = DriverManager.getConnection(url1, user, password);
            if (conn1 != null) {
                System.out.println("Connected to the database test");
            }
            Scanner sc = new Scanner(System.in);
            Statement st = conn1.createStatement();
            String s = "UPDATE prenotazioni SET `stato`='"+p.getStato()+"' WHERE ID_C='"+p.getId_corso()+"' AND Giorno='"+p.getGiorno()+"' AND Orario='"+p.getO_p()+"'";
            System.out.println("Query da lanciare : " + s);
            st.executeUpdate(s);
            System.out.println("Ho eseguito update dello stato della prenotazione!");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } finally {
            if (conn1 != null) {
                try {
                    conn1.close();
                } catch (SQLException e2) {
                    System.out.println(e2.getMessage());
                }
            }
        }
    }

    public static void insertCorso(Corsi c) {
        try {
            conn1 = DriverManager.getConnection(url1, user, password);
            if (conn1 != null) {
                System.out.println("Connected to the database test");
            }
            Statement st = conn1.createStatement();
            String s = "INSERT INTO corsi (Titolo) VALUES('" + c.getNome_corso() + "')";
            System.out.println("Query da lanciare : " + s);
            st.executeUpdate(s);
            System.out.println("Ho caricato il corso in tabella : corsi");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } finally {
            if (conn1 != null) {
                try {
                    conn1.close();
                } catch (SQLException e2) {
                    System.out.println(e2.getMessage());
                }
            }
        }
    }

    public static void deleteCorso(String titolo) throws SQLException {
        Connection conn2 = DriverManager.getConnection(url1, user, password);
        Statement st = conn2.createStatement();
        try {
            st.executeUpdate("UPDATE corsi SET attivo='"+0+"' WHERE Titolo='" + titolo + "';");
        } catch (SQLException e) {
            System.out.println("Errore in dropCorso: " + e.getMessage());
        } finally {
            try {
                st.close();
                conn2.close();
            } catch (SQLException e) {
                System.out.println("Errore in dropCorso: " + e.getMessage());
            }
        }
    }


    /* Query sui docenti */
    public static void insertDocenti(Docenti new_doc){
        try {
            conn1 = DriverManager.getConnection(url1, user, password);
            if (conn1 != null) {
                System.out.println("Connected to the database test");
            }
            Statement st = conn1.createStatement();
            String s = "INSERT INTO docenti (NomeD, CognomeD) VALUES('" + new_doc.getNome()+ "','" + new_doc.getCognome() + "')";
            System.out.println("Query da lanciare : " + s);
            st.executeUpdate(s);
            System.out.println("Ho caricato il docente in tabella : docenti");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } finally {
            if (conn1 != null) {
                try {
                    conn1.close();
                } catch (SQLException e2) {
                    System.out.println(e2.getMessage());
                }
            }
        }
    }

    public static void deleteDocenti() {
        ArrayList<Docenti> out = new ArrayList<>();
        try {
            conn1 = DriverManager.getConnection(url1, user, password);
            if (conn1 != null) {
                System.out.println("Connected to the database test");
            }
            System.out.println("WARNING!!\nDelete section!! Are you sure to continue? Y/N");
            Scanner sc1 = new Scanner(System.in);
            String choice = sc1.nextLine();
            if (choice.equals("Y") || choice.equals("y") || choice.equals("yes") || choice.equals("YES")) {
                Scanner sc = new Scanner(System.in);
                System.out.println("Give me surname : ");
                String surname = sc.nextLine();
                Statement st = conn1.createStatement();
                String s = "DELETE FROM docenti WHERE cognome ='" + surname + "'";
                System.out.println("Query da lanciare : " + s);
                st.executeUpdate(s);
                System.out.println("Ho eliminato da tabella : utenti la riga richiesta...");
            } else {
                System.out.println("Operation negated!");
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }


    //Trying Delete query...
    public static void queryDeleteonUtenti() {
        ArrayList<Utenti> out = new ArrayList<>();
        try {
            conn1 = DriverManager.getConnection(url1, user, password);
            if (conn1 != null) {
                System.out.println("Connected to the database test");
            }
            System.out.println("WARNING!!\nDelete section!! Are you sure to continue? Y/N");
            Scanner sc1 = new Scanner(System.in);
            String choice = sc1.nextLine();
            if (choice.equals("Y") || choice.equals("y") || choice.equals("yes") || choice.equals("YES")) {
                Scanner sc = new Scanner(System.in);
                System.out.println("Give me ID : ");
                int id = sc.nextInt();
                //Conto le occorrenze date dall'ID perché può capitare di avere più tuple con stesso numero
                /*int number_of_rows = CountOccurrencies();
                if(number_of_rows > 1){
                    System.out.println("You have with the same ID : "+number_of_rows+" occurrencies.\n This operation will automatically delete all the rows affected!! Be careful!");
                }*/
                Statement st = conn1.createStatement();
                String s = "DELETE FROM utenti WHERE id_utente =" + id + "";
                System.out.println("Query da lanciare : " + s);
                st.executeUpdate(s);
                System.out.println("Ho eliminato da tabella : utenti la riga richiesta...");
            } else {
                System.out.println("Operation negated!");
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } finally {
            if (conn1 != null) {
                try {
                    conn1.close();
                } catch (SQLException e2) {
                    System.out.println(e2.getMessage());
                }
            }
        }
    }

    public static void queryUpUtenti() {
        ArrayList<Utenti> out = new ArrayList<>();
        try {
            conn1 = DriverManager.getConnection(url1, user, password);
            if (conn1 != null) {
                System.out.println("Connected to the database test");
            }
            Scanner sc = new Scanner(System.in);
            //System.out.println("Give me id : ");
            //String id_ute = sc.nextLine();
            System.out.println("Give me account name : ");
            String name = sc.nextLine();
            System.out.println("Give me password : ");
            String pswd = sc.nextLine();
            System.out.println("Give me role : ");
            String role = sc.nextLine();
            Statement st = conn1.createStatement();
            String s = "INSERT INTO utenti (Account, Password, Ruolo) VALUES('" + name + "', '" + pswd + "', '" + role + "')";
            System.out.println("Query da lanciare : " + s);
            st.executeUpdate(s);
            System.out.println("Ho caricato i dati in tabella : utenti");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } finally {
            if (conn1 != null) {
                try {
                    conn1.close();
                } catch (SQLException e2) {
                    System.out.println(e2.getMessage());
                }
            }
        }
        //return out;
    }

    public static ArrayList<Utenti> queryDButenti() {
        ArrayList<Utenti> out = new ArrayList<>();

        try {
            conn1 = DriverManager.getConnection(url1, user, password);
            if (conn1 != null) {
                System.out.println("Connected to the database test");
            }

            Statement st = conn1.createStatement();
            ResultSet rs = st.executeQuery("SELECT * FROM utenti");
            while (rs.next()) {
                Utenti u = new Utenti(rs.getString("ID_UTENTE"), rs.getString("ACCOUNT"), rs.getString("PASSWORD"), rs.getString("RUOLO"));
                out.add(u);
            }


        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } finally {
            if (conn1 != null) {
                try {
                    conn1.close();
                } catch (SQLException e2) {
                    System.out.println(e2.getMessage());
                }
            }
        }
        return out;
    }

    public static int TeacherID(String nomeDoc, String cognomeDoc){
        int ID_D=0;
        try{
             conn1 = DriverManager.getConnection(url1, user, password);
             if (conn1 != null) {
                 System.out.println("Connected to the database test");
             }
             Statement st = conn1.createStatement();
             ResultSet result = st.executeQuery("SELECT ID_D FROM docenti WHERE NomeD='"+nomeDoc+"' AND CognomeD='"+cognomeDoc+"';");
             if(result.next()){
                 ID_D = result.getInt(1);
             }
             ID_D = result.getInt(1);
         }catch (SQLException e) {
             System.out.println(e.getMessage());
         } finally {
             if (conn1 != null) {
                 try {
                     conn1.close();
                 } catch (SQLException e2) {
                     System.out.println(e2.getMessage());
                 }
             }
         }
        return ID_D;
    }

    public static void insertTeaching(String titolo, String nomeDoc, String cognomeDoc) {
        try {
            conn1 = DriverManager.getConnection(url1, user, password);
            if (conn1 != null) {
                System.out.println("Connected to the database test");
            }
            Statement st = conn1.createStatement();
            int ID_D = DAO.TeacherID(nomeDoc, cognomeDoc);
            System.out.println("Teacher's ID is : "+ID_D);
            int ID_C = DAO.CourseID(titolo);
            System.out.println("Course ID : "+ID_C);
            String s = "INSERT INTO insegnamento(ID_D, ID_C, NomeC) VALUES("+ ID_D +" , "+ ID_C +" , '"+ titolo +"')";
            st.executeUpdate(s);
            System.out.println("Ho caricato i dati nella tabella `insegnamento`.");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } finally {
            if (conn1 != null) {
                try {
                    conn1.close();
                } catch (SQLException e2) {
                    System.out.println(e2.getMessage());
                }
            }
        }
    }

    public static void deleteTeaching(String title, String nomeD, String cognomeD){
        try {
            conn1 = DriverManager.getConnection(url1, user, password);
            if (conn1 != null) {
                System.out.println("Connected to the database test");
            }
            Statement st = conn1.createStatement();
            int ID_D = DAO.TeacherID(nomeD, cognomeD);
            System.out.println("Teacher's ID is : "+ID_D);
            int ID_C = DAO.CourseID(title);
            System.out.println("Course ID : "+ID_C);
            String s = "DELETE FROM insegnamento WHERE ID_D = "+ ID_D +" AND "+ ID_C +"  AND NomeC='"+ title +"';";
            st.executeUpdate(s);
            System.out.println("Ho eliminato correttamente dalla tabella `insegnamento`.");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } finally {
            if (conn1 != null) {
                try {
                    conn1.close();
                } catch (SQLException e2) {
                    System.out.println(e2.getMessage());
                }
            }
        }
    }

    public static int CourseID(String titolo) {
        int ID_C = 0;
        try{
            conn1 = DriverManager.getConnection(url1, user, password);
            if (conn1 != null) {
                System.out.println("Connected to the database test");
            }
            Statement st = conn1.createStatement();
            ResultSet result = st.executeQuery("SELECT ID_C FROM corsi WHERE Titolo='"+titolo+"';");
            if(result.next()){
                ID_C = result.getInt(1);
            }
            ID_C = result.getInt(1);
        }catch (SQLException e) {
            System.out.println(e.getMessage());
        } finally {
            if (conn1 != null) {
                try {
                    conn1.close();
                } catch (SQLException e2) {
                    System.out.println(e2.getMessage());
                }
            }
        }
        return ID_C;
    }

    public static void deleteFromTeaching(Docenti doc) {
        ArrayList<Insegnamento> out = new ArrayList<>();
        try {
            conn1 = DriverManager.getConnection(url1, user, password);
            if (conn1 != null) {
                System.out.println("Connected to the database test");
            }
            else {
                System.out.println("Operation negated!");
            }
            System.out.println("WARNING!!\nDelete section!! Are you sure to continue? Y/N");
                Statement st = conn1.createStatement();
                String s = "DELETE FROM insegnamento WHERE id_corso=" + doc.getId() + " AND nome_docente='" + doc.getNome() + "' AND cognome_docente='" + doc.getCognome() + "'";
                System.out.println("Query da lanciare : " + s);
                st.executeUpdate(s);
                System.out.println("Ho eliminato da tabella : insegnamento la riga contente ID:" + doc.getId() + " e Nome Docente : " + doc.getNome() + " e Cognome Docente:" + doc.getCognome() + "...");
            }
            catch (SQLException e) {
                e.printStackTrace();
            }
    }

    /* Query prenotazioni */
    public static void InsertPrenotazioni(Prenotazione p){
        try{
            conn1 = DriverManager.getConnection(url1, user, password);
            if (conn1 != null) {
                System.out.println("Connected to the database test");
            }
            System.out.println("Insert a booking...");
            Statement st = conn1.createStatement();
            String s = "INSERT INTO prenotazioni (ID_U, ID_C, Orario, Giorno) VALUES('" + p.getId_utente() + "', '" + p.getId_corso() + "' , '" + p.getO_p() + "' , '" + p.getGiorno()+ "')";
            System.out.println("Query da lanciare : " + s);
            st.executeUpdate(s);
        }catch(SQLException e){
            e.printStackTrace();
        }
    }

    public static void DeletePrenotazioni(Prenotazione p){
        Connection conn1 = null;
        try{
            conn1 = DriverManager.getConnection(url1, user, password);
            if (conn1 != null) {
                System.out.println("Connected to the database test");
            }
            System.out.println("Delete a booking...");
            Statement st = conn1.createStatement();
            String q = "DELETE FROM prenotazioni WHERE Giorno='"+p.getGiorno()+"' AND Orario='"+p.getO_p()+"'";
            System.out.println("Query da lanciare : " + q);
            st.executeUpdate(q);
            System.out.println("Hai eleminato correttamente la prenotazione per il corso avente orario uguale.");
        }catch(SQLException e){
            e.printStackTrace();
        }
    }

    public static Prenotazioni showPersonalBooking(String id_ute) {
        Prenotazioni lprenotazioni = new Prenotazioni();
        try {
            conn1 = DriverManager.getConnection(url1, user, password);
            if (conn1 != null) {
                System.out.println("Connected to the database test");
            }

            Statement st = conn1.createStatement();
            ResultSet rs = st.executeQuery("SELECT ID_C, Orario, Giorno, Stato FROM prenotazioni WHERE ID_U='"+id_ute+"'");
            while (rs.next()) {
                Prenotazione p = new Prenotazione(id_ute, rs.getString("ID_C"), rs.getString("ORARIO"), rs.getString("GIORNO"), rs.getString("STATO"));
                lprenotazioni.inserisci(p);
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } finally {
            if (conn1 != null) {
                try {
                    conn1.close();
                } catch (SQLException e2) {
                    System.out.println(e2.getMessage());
                }
            }
        }
        return lprenotazioni;
    }

    public static Prenotazioni showAllBooking(){
        Prenotazioni prenotazioni = new Prenotazioni();
        try {
            conn1 = DriverManager.getConnection(url1, user, password);
            if (conn1 != null) {
                System.out.println("Connected to the database test");
            }

            Statement st = conn1.createStatement();

            ResultSet rs = st.executeQuery("SELECT * FROM prenotazioni");
            while (rs.next()) {
                Prenotazione p = new Prenotazione(rs.getString("ID_U"), rs.getString("ID_C"), rs.getString("ORARIO"), rs.getString("GIORNO"), rs.getString("STATO"));
                prenotazioni.inserisci(p);
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } finally {
            if (conn1 != null) {
                try {
                    conn1.close();
                } catch (SQLException e2) {
                    System.out.println(e2.getMessage());
                }
            }
        }
        return prenotazioni;
    }

    //Ritorna la lista delle prenotazioni di tutti gli utenti
    public static Prenotazioni retrieveList(){
            Prenotazioni lpr = new Prenotazioni();
            /* Creo connessione */
            try{
                conn1 = DriverManager.getConnection(url1, user, password);
                if (conn1 != null) {
                    System.out.println("Connected to the database test");
                }
                Statement st = conn1.createStatement();
                ResultSet rs = st.executeQuery("SELECT ID_U, ID_C, ORARIO, GIORNO, STATO FROM `prenotazioni`");
                while (rs.next()) {
                    Prenotazione pren = new Prenotazione( rs.getString("ID_U"),rs.getString("ID_C"), rs.getString("ORARIO"), rs.getString("GIORNO"), rs.getString("STATO"));
                    lpr.inserisci(pren);
                }

            }catch(SQLException e){
                System.out.println(e.getMessage());
            }
            finally{
                if (conn1 != null) {
                    try {
                        conn1.close();
                    } catch (SQLException e2) {
                        System.out.println(e2.getMessage());
                    }
                }
            }
            return lpr;
    }
}
