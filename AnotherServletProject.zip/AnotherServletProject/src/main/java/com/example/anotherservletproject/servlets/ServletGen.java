package com.example.anotherservletproject.servlets;

import com.example.anotherservletproject.dao.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import com.google.gson.Gson;
import java.util.List;

public class ServletGen {

    public static void processRequest(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        String current_user = request.getParameter("utente");
        String password = request.getParameter("password");
        String role = "";
        HttpSession userSession = request.getSession();
        System.out.println("Current user : " + current_user);
        role = DAO.UserRole(current_user);
        userSession.setAttribute("user", current_user);
        userSession.setAttribute("pswd", password);
        userSession.setAttribute("role", role);
        out.print(role);
        out.flush();
    }

    public static void OwnBooking(HttpServletRequest request, HttpServletResponse response) throws IOException{
        HttpSession session = request.getSession();
        Gson json = new Gson();
        Prenotazioni p = null;
        String user = (String) session.getAttribute("user");
        String role = (String) session.getAttribute("role");
        String id_ute = DAO.UserID(user);
        System.out.println("ID Utente : "+id_ute);
        if(session.isNew()){
            response.setContentType("text/html;charset=UTF-8");
            PrintWriter out = response.getWriter();
            out.print("invalidate");
        }else {
            response.setContentType("application/json");
            PrintWriter out = response.getWriter();
            try {
                p = DAO.showPersonalBooking(id_ute);
            }catch(Exception exp){
                System.out.println(exp.getMessage());
            }
            System.out.println("Accesso correttamente effettuato per il json");
            out.print(json.toJson(p));
        }
    }

    public static void InsertTeacher(HttpServletRequest request, HttpServletResponse response) throws IOException{
        //Inizializzo una sessione per l'admin
        HttpSession adminSession = request.getSession();
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        String utente = (String) adminSession.getAttribute("user");
        String ruolo = (String) adminSession.getAttribute("role");
        String nomeD = request.getParameter("nome");
        String cognomeD = request.getParameter("cognome");
        String id_ute = DAO.UserID(utente);
        String result = "";
        System.out.println("ID Utente : "+id_ute+" Ruolo : "+ruolo);
        System.out.println("Nome Docente : "+nomeD+" | Cognome Docente : "+cognomeD);
        if(adminSession.isNew() || !ruolo.equals("amministratore")){
            //invalido la sessione
            out.print("Sessione invalidata!");
            adminSession.invalidate();
        }else{
            try{
                Docenti doc = new Docenti(nomeD, cognomeD);
                DAO.insertDocenti(doc);
                result = "done";
            }catch(Exception e){
                System.out.println("Errore : "+e.getMessage());
                result = "failed!";
            }
            out.print(result);
            System.out.println("Result is : "+result);
        }
    }

    public static void InsertCorso(HttpServletRequest request, HttpServletResponse response) throws IOException{
        //Inizializzo una sessione per l'admin
        HttpSession adminSession = request.getSession();
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        String utente = (String) adminSession.getAttribute("user");
        String ruolo = (String) adminSession.getAttribute("role");
        System.out.println("Nome utente : "+utente+" & Ruolo : "+ruolo);
        String titoloCorso = request.getParameter("nomeCorso");
        String id_ute = DAO.UserID(utente);
        String result = "";
        System.out.println("ID Utente : "+id_ute+" Ruolo : "+ruolo);
        System.out.println("Titolo Corso : "+titoloCorso);
        if(adminSession.isNew() || !ruolo.equals("amministratore")){
            //invalido la sessione
            out.print("Sessione invalidata!");
            adminSession.invalidate();
        }else{
            try{
                Corsi c = new Corsi(titoloCorso);
                System.out.println("Corso creato! Titolo : "+c.getNome_corso());
                DAO.insertCorso(c);
                result = "done";
            }catch(Exception e){
                System.out.println("Errore : "+e.getMessage());
                result = "failed!";
            }
            out.print(result);
            System.out.println("Result is : "+result);
        }
    }

    public static void DeleteCorso(HttpServletRequest request, HttpServletResponse response) throws IOException{
        //Inizializzo una sessione per l'admin
        HttpSession adminSession = request.getSession();
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        String titolo = request.getParameter("nomeCorso");
        String ruolo = (String) adminSession.getAttribute("role");
        String result = "";
        System.out.println("Ruolo : "+ruolo);
        System.out.println("Titolo Corso : "+titolo);
        if(adminSession.isNew() || !ruolo.equals("amministratore")){
            //invalido la sessione
            out.print("Sessione invalidata!");
            adminSession.invalidate();
        }else{
            try{
                DAO.deleteCorso(titolo);
                result = "done";
            }catch(Exception e){
                System.out.println("Errore : "+e.getMessage());
                result = "failed!";
            }
            out.print(result);
            System.out.println("Result is : "+result);
        }
    }

    public static void InsertTeaching(HttpServletRequest request, HttpServletResponse response) throws IOException{
        HttpSession adminSession = request.getSession();
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        String titolo = request.getParameter("nomeCorso");
        String nomeDoc = request.getParameter("nomeDoc");
        String cognomeDoc = request.getParameter("cognomeDoc");
        String ruolo = (String) adminSession.getAttribute("role");
        String result = "";
        System.out.println("Ruolo : "+ruolo);
        System.out.println("Titolo Corso : "+titolo);
        if(adminSession.isNew() || !ruolo.equals("amministratore")){
            //invalido la sessione
            out.print("Sessione invalidata!");
            adminSession.invalidate();
        }else{
            try{
                DAO.insertTeaching(titolo, nomeDoc, cognomeDoc);
                result = "done";
            }catch(Exception e){
                System.out.println("Errore : "+e.getMessage());
                result = "failed!";
            }
            out.print(result);
            System.out.println("Result is : "+result);
        }
    }

    public static void DeleteTeaching(HttpServletRequest request, HttpServletResponse response) throws IOException{
        HttpSession adminSession = request.getSession();
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        String titolo = request.getParameter("nomeCorso");
        String nomeDoc = request.getParameter("nomeDoc");
        String cognomeDoc = request.getParameter("cognomeDoc");
        String ruolo = (String) adminSession.getAttribute("role");
        String result = "";
        System.out.println("Ruolo : "+ruolo);
        System.out.println("Titolo Corso : "+titolo);
        if(adminSession.isNew() || !ruolo.equals("amministratore")){
            //invalido la sessione
            out.print("Sessione invalidata!");
            adminSession.invalidate();
        }else{
            try{
                DAO.deleteTeaching(titolo, nomeDoc, cognomeDoc);
                result = "done";
            }catch(Exception e){
                System.out.println("Errore : "+e.getMessage());
                result = "failed!";
            }
            out.print(result);
            System.out.println("Result is : "+result);
        }
    }
}
