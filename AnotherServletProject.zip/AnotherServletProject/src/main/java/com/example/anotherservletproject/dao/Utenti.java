package com.example.anotherservletproject.dao;

public class Utenti {
    private String id;
    private String account;
    private String password;
    private String ruolo;

    public Utenti(String id, String account, String ruolo) {
        this.id = id;
        this.account = account;
        this.ruolo = ruolo;
    }

    public Utenti(String id,String account, String password, String ruolo) {
        this.id = id;
        this.account = account;
        this.password = password;
        this.ruolo = ruolo;
    }

    /* Getter & Setter */

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRuolo() {
        return ruolo;
    }

    public void setRuolo(String ruolo) {
        this.ruolo = ruolo;
    }

    @Override
    public String toString() {
        return id + " , " +account + " , " + ruolo;
    }

}
