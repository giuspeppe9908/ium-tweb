package com.example.anotherservletproject.servlets;

import javax.servlet.annotation.WebServlet;

@WebServlet(name = "teacherServlet", value = "/teacher-servlet")
public class TeacherServlet {



}
