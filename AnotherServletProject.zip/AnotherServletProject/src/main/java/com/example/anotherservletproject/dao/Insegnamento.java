package com.example.anotherservletproject.dao;

public class Insegnamento {

    int id, id_cor;
    String nome_doc, cognome_doc;

    public Insegnamento(int id, int id_cor, String nome_doc, String cognome_doc) {
        this.id = id;
        this.nome_doc = nome_doc;
        this.cognome_doc = cognome_doc;
        this.id_cor = id_cor;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome_doc() {
        return nome_doc;
    }

    public void setNome_doc(String nome_doc) {
        this.nome_doc = nome_doc;
    }

    public String getCognome_doc() {
        return cognome_doc;
    }

    public void setCognome_doc(String cognome_doc) {
        this.cognome_doc = cognome_doc;
    }

    public int getID_cor() {
        return id_cor;
    }

    public void setID_cor(int id_cor) {
        this.id_cor = id_cor;
    }

    @Override
    public String toString(){
        String s = "{ ID_DOCENTE : "+id+", ID_CORSO : "+id_cor+", Nome Docente : "+nome_doc+", Cognome Docente : "+cognome_doc+"}";
        return s;
    }
}
