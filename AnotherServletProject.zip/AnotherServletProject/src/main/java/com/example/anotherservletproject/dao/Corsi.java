package com.example.anotherservletproject.dao;

public class Corsi {

    int ID;
    String nome_corso, attivo;

    public Corsi(){

    }

    public Corsi(String nome_corso){
        this.nome_corso = nome_corso;
    }

    public Corsi(int ID, String nome_corso, String attivo) {
        this.ID = ID;
        this.nome_corso = nome_corso;
        this.attivo = attivo;
    }

    public String getAttivo() {
        return attivo;
    }

    public void setAttivo(String attivo) {
        this.attivo = attivo;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getNome_corso() {
        return nome_corso;
    }

    public void setNome_corso(String nome_corso) {
        this.nome_corso = nome_corso;
    }

    @Override
    public String toString() {
        return ID + ", " + nome_corso + ", " + attivo;
    }
}
