package com.example.anotherservletproject.dao;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Prenotazioni implements Serializable {

    private final List<Prenotazione> prenotazioni = new ArrayList<>();

    public void inserisci(Prenotazione p){
        prenotazioni.add(p);
    }

    public List<Prenotazione> getAttive(){return this.prenotazioni;}
}
