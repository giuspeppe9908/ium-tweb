package com.example.anotherservletproject.servlets;

import com.example.anotherservletproject.dao.*;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(name = "insertServlet", value = "/insert-servlet")
public class FormDocenti extends HttpServlet{
    String message;
    public void init() {
        message = "TEACHER ADDED SUCCESSFULLY!";
        DAO.registerDriver();
    }

    /*public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("text/html");
        Docenti doce = new Docenti();
        doce.setId(request.getParameter("id_doc"));
        doce.setNome(request.getParameter("name"));
        doce.setCognome(request.getParameter("surname"));
        doce.setCorso(request.getParameter("id_C"));
        DAO.insertDocenti(doce);
        PrintWriter out = response.getWriter();
        out.println("<html><head><meta http-equiv=\'refresh\' content=\'5; url=formdoc.html\'></head><body>");
        out.println("<p> Hai inserito correttamente il docente! </p>");
        out.println("</html></body>");
    }*/

}
