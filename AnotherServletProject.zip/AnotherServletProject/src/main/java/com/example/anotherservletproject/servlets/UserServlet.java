package com.example.anotherservletproject.servlets;

import com.example.anotherservletproject.dao.DAO;
import com.example.anotherservletproject.dao.Utenti;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

@WebServlet(name = "userServlet", value = "/user-servlet")
public class UserServlet extends HttpServlet{
    private String message;

    public void init() {
        message = "LIST OF USERS!";
        DAO.registerDriver();
    }

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("text/html");
        ArrayList<Utenti> p = DAO.queryDButenti();
        PrintWriter out = response.getWriter();
        out.println("<html><body>");
        out.println("<h1>" + message + "</h1>");
        for(Utenti u : p){
            out.println("<p>"+ u + "</p>");
        }
        out.println("</body></html>");
    }

    public void destroy() {
    }
}
